export class Rol{
    idRol: number;
    nombre: string;
}