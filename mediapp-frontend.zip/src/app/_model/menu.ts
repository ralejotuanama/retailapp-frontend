import { Rol } from './rol';

export class Menu{
    idMenu: number;
    icono: string;
    nombre: string;
    url: string;
    roles: Rol[];
}